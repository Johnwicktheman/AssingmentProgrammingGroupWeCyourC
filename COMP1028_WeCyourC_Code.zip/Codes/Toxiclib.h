
#ifndef Test
#define Test
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

// --- MACROS ---
#define BUFFER_SIZE 10000 // General buffer size for various uses
#define MAX_WORDS 10000000 // Maximum number of words to read from file
#define MAX_TOXICWORDS 2000 // Maximum number of toxic words
#define MAX_STOPWORDS 900 // Maximum number of stopwords
#define MAX_WORD_LEN 51 // Maximum length of a word (including null terminator)


// CRT_SECURE_NO_WARNINGS is usually a compiler flag, not a code macro.
extern char stopwords[MAX_STOPWORDS][MAX_WORD_LEN]; // Initialize stopwords array
extern char toxicwords[MAX_TOXICWORDS][MAX_WORD_LEN]; // Initialize toxicwords array
extern int stopwordCount; // Declare stopword count
extern int toxicwordCount; // Declare toxic word count

extern FILE* fptr, * file; // Declare file pointers for file operations
extern char content[MAX_WORDS]; // Initialize content buffer for file content extraction & storage
extern char word_ADD[BUFFER_SIZE]; // Initialize a buffer for adding words
extern char file_name[BUFFER_SIZE]; // Initialize a buffer for file names
extern char input_buffer[100]; // Initialize a general input buffer

// --- STRUCTURES ---
typedef struct {
    char word[MAX_WORD_LEN];
    int freq;
} WordEntry; // Structure to hold unique word and its frequency

typedef struct {
    char toxicword[MAX_WORD_LEN];
    int freqtoxic;
} ToxicWordEntry; // Structure to hold unique toxic word and its frequency

typedef struct {
    // Dynamic lists and their counts/capacities
    WordEntry* uniqueWords;
    int uniqueCount;
    int uniqueCapacity;

    ToxicWordEntry* uniqueToxicWords;
    int uniqueToxicCount;
    int uniqueToxicCapacity;

    // General Stats
    int totalWords;
    int toxicWordFound;
    int characterCount;
    int letterCount;
    int punctCount;
    int digitCount;
    int whitespaceCount;
    int sentenceCount;
    float AverageSentenceCount;

    // Ratios
    float uniqueRatio;
    float toxicRatio;

    // File handling
    char filename[MAX_WORD_LEN];
} AnalysisResults;

typedef struct {
    char filename[MAX_WORD_LEN];
    float toxicRatio;
} ComparisonData;

// --- GLOBAL (EXTERNAL) DECLARATIONS ---
// The actual storage for these will be in main.c or text_analyzer.c
extern char stopwords[MAX_STOPWORDS][MAX_WORD_LEN];
extern char toxicwords[MAX_TOXICWORDS][MAX_WORD_LEN];
extern int stopwordCount;
extern int toxicwordCount;

// --- FUNCTION PROTOTYPES ---
// Loaders and Checkers
int loadStopwords(char stopwords[][MAX_WORD_LEN], const char* filename);
int isStopword(char* word, char stopwords[][MAX_WORD_LEN], int count);
int loadToxicwords(char toxicwords[][MAX_WORD_LEN], const char* filename);
int isToxicword(char* word, char toxicwords[][MAX_WORD_LEN], int count);

// Word Tracking (must return pointer due to realloc)
WordEntry* isUniqueWord(char* word, WordEntry* uniqueWords, int* uniqueCount, int* uniqueCapacity);
ToxicWordEntry* trackToxicWord(char* word, ToxicWordEntry* toxicEntries, int* count, int* capacity);

// Sorting
void bubbleSort(WordEntry* uniqueWords, int count); // Sort unique words by frequency
void bubbleSortToxic(ToxicWordEntry* toxicWords, int count); // Sort toxic words by frequency

// Main Logic
void generalStats(AnalysisResults* results); // Function to compute general statistics for Menu option 2
void Save_results_csv(AnalysisResults* results); // Function to save analysis results to CSV for Menu option 5
void add_words(); // Function to add words to toxicwords.txt dictionary for Menu option 6
void bar_chart(AnalysisResults* results); // Function to display bar chart of top 10 words for Menu option 4
void ToxicDisplay(AnalysisResults* results); // Function to display toxicity stats for Menu option 3
void compareToxicity(); // Function to compare toxicity between two analysis files for Menu option 7
char file_menu(AnalysisResults* results); // Function to input files for Menu option 1
int menu(AnalysisResults* results); // Function to display menu and handle user choices

#endif