#include "Toxiclib.h" //Include every function from header file

//Function that loads stopwords file and then count the number of stopwords present
int loadStopwords(char stopwords[][MAX_WORD_LEN], const char* filename) {
    FILE* fp = fopen(filename, "r"); // Open filename called stopwords.txt for reading
    
    if (fp == NULL) { //If fp is NULL that means no stopwords.txt file so cannot read
        perror("Error: Could not open stopwords file.\n\n");
        return 0; // Sent error to indicate failure
    }

    int count = 0; // Initialize the stopword count to 0

    // Loop through the file to read each stopword
    while (fscanf(fp, "%45s", stopwords[count]) == 1) {

        for (int i = 0; stopwords[count][i] != '\0'; i++) { // Read the string until \0
            stopwords[count][i] = tolower(stopwords[count][i]); // Standardize to lowercase
        }

        count++; // Increment count for next row

        if (count >= MAX_STOPWORDS) { // Check if array counter exceeds maximum capacity
            break;
        }
        // we need the stopword count to know how many recursions required later
    }

    fclose(fp); // Close the stopwords file after reading
    return count; //return amount of stopwords were loaded
}

// Function to detect stopwords in user's input file content
int isStopword(char* word, char stopwords[][MAX_WORD_LEN], int count) {
    for (int i = 0; i < count; i++) { // Here we used the stopword count calculated prior
        if (strcmp(word, stopwords[i]) == 0) {// Check if it's a stopword by comparing the tokenized content with the stopwords list
            return 1; //Yes it's a stop word
        }

    }
    return 0; //Not a stopword
}

//Function that loads toxicwords file and then count the number of toxicwords present
int loadToxicwords(char toxicwords[][MAX_WORD_LEN], const char* filename) {
    FILE* fp = fopen(filename, "r"); // Open toxicwords.txt for reading
    if (fp == NULL) { // Check if file is present
        perror("Error: Could not open toxicwords file.\n\n");
        return 0;
    }

    int count = 0; // Initialize the toxic word count to 0
    
    // Loop through the file to read each toxic word
    while (fscanf(fp, "%45s", toxicwords[count]) == 1) {
        for (int i = 0; toxicwords[count][i] != '\0'; i++) {
            toxicwords[count][i] = tolower(toxicwords[count][i]); //Normalize the toxic words
        }
        count++; // Increment count for next row
        if (count >= MAX_TOXICWORDS) { // Check if array counter exceeds maximum capacity
            break;
        }
    }
    fclose(fp);
    return count; //return amount of toxic words loaded
}

// Function to detect toxicwords in user's input file content
int isToxicword(char* word, char toxicwords[][MAX_WORD_LEN], int count) {
    for (int i = 0; i < count; i++) {
        if (strcmp(word, toxicwords[i]) == 0) {
            return 1; //Yes it's a toxic word
        }
    }
    return 0; //Not a toxic word
}

// Struct function to add unique words and track their frequency
WordEntry* isUniqueWord(char* word, WordEntry* uniqueWords, int* uniqueCount, int* uniqueCapacity) {

    for (int i = 0; i < *uniqueCount; i++) {
        if (strcmp(word, uniqueWords[i].word) == 0) { // Check if word already exists
            uniqueWords[i].freq++; // If already exists, increment frequency
            return uniqueWords;  // Word already existed, pointer unchanged
        }
    }

    // Reallocate if needed
    if (*uniqueCount == *uniqueCapacity) {
        *uniqueCapacity *= 2;
        uniqueWords = realloc(uniqueWords, *uniqueCapacity * sizeof(WordEntry));
        //Note that this is below the for loop as the remaining words detected by the for loop may all have already existed, therefore not requiring a realloc

        //Check if memory was reallocated and isn't NULL
        if (!uniqueWords) {
            printf("Memory allocation failed!\n\n");
            exit(1); //Exit if realloc failed
        }
        // If there wasn't enough memory to realloc, it returns NULL. Continuing to use NULL will crash the program so a check must be done
    }


    // If word not found, add it to the found unique word list
    strcpy(uniqueWords[*uniqueCount].word, word);
    uniqueWords[*uniqueCount].freq = 1;   // Set the first occurence of this word
    (*uniqueCount)++;   //increment total unique words 

    return uniqueWords;  // Return the possibly updated pointer

}
//Note that the function is initiaized with WordEntry* so that it returns a pointer
//We need to return the pointer because IF realloc occurs, the pointer will only change locally. So we return the pointer in case it happened

// Struct function to add unique toxic words and track their frequency
ToxicWordEntry* trackToxicWord(char* word, ToxicWordEntry* toxicEntries, int* count, int* capacity) {
    // Check if word already exists in the toxic entries array
    for (int i = 0; i < *count; i++) {
        if (strcmp(word, toxicEntries[i].toxicword) == 0) {
            toxicEntries[i].freqtoxic++;
            return toxicEntries; // Word found and frequency updated
        }
    }

    // If word not found, check if reallocation is needed
    if (*count == *capacity) {
        *capacity *= 2;
        // Reallocate memory for the array of structs
        toxicEntries = realloc(toxicEntries, *capacity * sizeof(ToxicWordEntry));

        if (!toxicEntries) { // Check if realloc was successful
            printf("Memory allocation failed for toxic words!\n");
            exit(1); // Exit if realloc failed
        }
    }

    // If word not found, add it to the found unique toxic word list
    strcpy(toxicEntries[*count].toxicword, word);
    toxicEntries[*count].freqtoxic = 1;
    (*count)++; // Increment the total number of unique toxic words

    return toxicEntries; // Return the potentially updated pointer
}

// Bubblesort the unique words by their frequency
void bubbleSort(WordEntry* uniqueWords, int count) {
    for (int i = 0; i < count - 1; i++) {
        for (int j = 0; j < count - 1 - i; j++) {
            WordEntry tempStruct;
            if (uniqueWords[j].freq < uniqueWords[j + 1].freq) {
                tempStruct = uniqueWords[j];
                uniqueWords[j] = uniqueWords[j + 1];
                uniqueWords[j + 1] = tempStruct;
            }
        }
    }
}

// Bubblesort the unique toxic words by their frequency
void bubbleSortToxic(ToxicWordEntry* toxicWords, int count) {
    for (int i = 0; i < count - 1; i++) {
        for (int j = 0; j < count - 1 - i; j++) {
            ToxicWordEntry tempStruct;
            if (toxicWords[j].freqtoxic < toxicWords[j + 1].freqtoxic) {
                tempStruct = toxicWords[j];
                toxicWords[j] = toxicWords[j + 1];
                toxicWords[j + 1] = tempStruct;
            }
        }
    }
}

// Function to compute general statistics from the loaded file
void generalStats(AnalysisResults* results) {
    FILE* fptr = fopen("read.txt", "r"); // Read the conversion file
    if (fptr == NULL) { // Check if file opened successfully
        printf("Error: Unable to open read.txt\n\n");
        fclose(fptr); // Close the file pointer
        return; // Return error
    }

    // Load word lists locally (using the global arrays/counts to save time)
    int current_stopwordCount = loadStopwords(stopwords, "stopwords.txt");
    int current_toxicwordCount = loadToxicwords(toxicwords, "toxicwords.txt");
    
    // Use a local buffer for file reading
    char* buffer = (char*)malloc(MAX_WORDS * sizeof(char)); // Allocate sufficient memory for buffer
    if (buffer == NULL) { // Check if malloc failed
        perror("Error: Memory allocation for buffer failed!\n\n");
        fclose(fptr); // Close file pointer
        return; // Return error
    }
    

    // Reset/clear previously calculated word lists
    results->uniqueCount = 0;
    results->uniqueToxicCount = 0;
    results->totalWords = 0;
    results->uniqueCount = 0;
    results->toxicWordFound = 0;
    results->characterCount = 0;
    results->letterCount = 0;
    results->punctCount = 0;
    results->digitCount = 0;
    results->whitespaceCount = 0;
    results->sentenceCount = 0;
    results->AverageSentenceCount = 0;

    // Read the file content into the buffer and process it
    while (fgets(buffer, MAX_WORDS, fptr)) {
        for (int i = 0; buffer[i] != '\0'; i++) { // Read the string until \0
            char c = buffer[i];
            results->characterCount++; // Count every character including whitespace and punctuation

            // Convert \r to whitespace for strtok
            if (c == '\r') { buffer[i] = ' '; results->whitespaceCount++; continue; }

            // Count letters, digits, whitespaces, sentences, and punctuation
            if (isalpha((unsigned char)c)) results->letterCount++;
            if (isdigit((unsigned char)c)) results->digitCount++;
            if (isspace((unsigned char)c)) results->whitespaceCount++;

            // Check for sentence-ending punctuation
            if (c == '.' || c == '?' || c == '!') results->sentenceCount++;

            // Then, we checked for other punctuation marks
            if (ispunct((unsigned char)c)) { results->punctCount++; buffer[i] = ' '; } // If punctuation is found, replace it with whitespace for strtok
            else buffer[i] = (char)tolower((unsigned char)c); // Standardize to lowercase
        }

        char* word = strtok(buffer, " \t\n\r"); // Tokenize the buffer into words based on delimiters
        while (word != NULL) {
            size_t len = strlen(word); // Get the length of the tokenized word

            while (*word && !isalpha((unsigned char)*word)) { word++; }
            len = strlen(word); // Update length after trimming leading non-alphabetic characters

            while (len && !isalpha((unsigned char)word[len - 1])) { word[--len] = '\0'; } // Add \0 to end after trimming trailing non-alphabetic characters

            if (len > 0 && !isStopword(word, stopwords, current_stopwordCount)) {
                results->totalWords++; // Count total words excluding stopwords

                // IMPORTANT: Update the struct's pointer in case realloc happens
                results->uniqueWords = isUniqueWord(word, results->uniqueWords, &results->uniqueCount, &results->uniqueCapacity);

                if (isToxicword(word, toxicwords, current_toxicwordCount)) {
                    results->toxicWordFound++; // Increment toxic word count if toxic word found

                    // IMPORTANT: Update the struct's pointer in case realloc happens
                    results->uniqueToxicWords = trackToxicWord(word, results->uniqueToxicWords, &results->uniqueToxicCount, &results->uniqueToxicCapacity);
                }
            }

            word = strtok(NULL, " \t\n\r"); // End the tokenization loop by tokenizing NULL
        }
    }

    fclose(fptr);
    free(buffer);// Free the allocated memory for buffer
    buffer = NULL; 
    
    // Sort the struct's data
    bubbleSort(results->uniqueWords, results->uniqueCount);
    bubbleSortToxic(results->uniqueToxicWords, results->uniqueToxicCount);

    // Calculate final ratios and store in struct
    results->uniqueRatio = results->totalWords ? (float)results->uniqueCount / results->totalWords : 0.0f;
    results->toxicRatio = results->totalWords ? (float)results->toxicWordFound / results->totalWords : 0.0f;

    // Print results from the struct fields
    printf("\n--------- General Text Statistics ---------\n");
    printf("Total words (excluding stopwords): %d\n", results->totalWords);
    printf("Number of characters in text: %d\n", results->characterCount);
    printf("Number of letters in text: %d\n", results->letterCount);
    printf("Number of punctuation in text: %d\n", results->punctCount);
    printf("Number of digits in text: %d\n", results->digitCount);
    printf("Number of whitespaces in text: %d\n", results->whitespaceCount);
    printf("Number of unique words: %d\n", results->uniqueCount);
    printf("Percentage of unique words to total words: %.2f%%\n", results->uniqueRatio * 100);
    printf("Number of sentences in text: %d\n", results->sentenceCount);
    if (results->sentenceCount > 0) { // Check if input file has sentences
        results->AverageSentenceCount = (float)results->totalWords / results->sentenceCount;
        printf("Average sentence length: %.2f words\n\n", (float)results->totalWords / results->sentenceCount);
    }
    else {
        printf("No sentences found, cannot compute average sentence length.\n\n");
    }
}

// Function to input a file for analysis
char file_menu(AnalysisResults* results) {
    // Clear the previous analysis results if any
    results->uniqueCount = 0;
    results->uniqueToxicCount = 0;
    results->totalWords = 0;
    results->uniqueCount = 0;
    results->toxicWordFound = 0;
    results->characterCount = 0;
    results->letterCount = 0;
    results->punctCount = 0;
    results->digitCount = 0;
    results->whitespaceCount = 0;
    results->sentenceCount = 0;
    results->AverageSentenceCount = 0;

    printf("Enter file name (case-sensitive): "); // Prompt user for file name
    if (fgets(file_name, sizeof(file_name), stdin) != NULL) { // Check if user input is valid
        file_name[strcspn(file_name, "\n")] = 0; // Replace \n with null terminator
    }

    FILE* temp_fptr = fopen(file_name, "r"); // Try to open the user-specified file
    
    // Check file's existence
    if (temp_fptr == NULL) {
        printf("\nCan't open file/Non-existent.\n\n");
        return 1; // Return error code if file cannot be opened/non-existent
    } else {
        strcpy(results->filename, file_name); // Store filename in the struct
    }

    size_t bytesRead = fread(content, 1, sizeof(content) - 1, temp_fptr); // Read file content into global buffer
    content[bytesRead] = '\0'; // Set the last byte to null terminator
    fclose(temp_fptr); // Close the temporary file pointer

    temp_fptr = fopen("read.txt", "w"); // Open/create conversion file
    
    if (!temp_fptr) { // Check if file opened successfully
        perror("Error opening read.txt for write.\n\n");
        return 1;
    }

    fwrite(content, 1, bytesRead, temp_fptr); // Write content to read.txt
    fclose(temp_fptr); // Close the file after writing
    printf("File's content has been extracted and stored.\n\n"); // Print succesful message
    return 0;
}

void Save_results_csv(AnalysisResults* results) {
    //copy the filename inputted by user from Menu option 1 to outputfilename
    char outputFilename[MAX_WORD_LEN];
    strncpy(outputFilename, results->filename, MAX_WORD_LEN);
    outputFilename[MAX_WORD_LEN - 1] = '\0';

    char* dot = strrchr(outputFilename, '.'); // Check the filename for a dot extension; e.g. .txt
    if (dot != NULL && dot != outputFilename) *dot = '\0'; // Remove the extension if found

    // Append "_analysis.csv" to the filename to make it an output CSV file
    strncat(outputFilename, "_analysis.csv", sizeof(outputFilename) - strlen(outputFilename) - 1);

    FILE* out_fp = fopen(outputFilename, "w"); // Open the output file for writing
    if (out_fp == NULL) { // Check if file opened successfully
        printf("\nError: Could not open output file '%s' for writing.\n\n", outputFilename);
        return;
    }

    // --- Write Global Stats Summary to output file ---
    fprintf(out_fp, "Source_File:,%s\n", results->filename);
    fprintf(out_fp, "\nGeneral_Text_Statistics\n");
    fprintf(out_fp, "Metric,Value\n");
    fprintf(out_fp, "\nTotal words (excluding stopwords):,%d\n", results->totalWords);
    fprintf(out_fp, "Number of characters in text:,%d\n", results->characterCount);
    fprintf(out_fp, "Number of letters in text:,%d\n", results->letterCount);
    fprintf(out_fp, "Number of punctuation in text:,%d\n", results->punctCount);
    fprintf(out_fp, "Number of digits in text:,%d\n", results->digitCount);
    fprintf(out_fp, "Number of whitespaces in text:,%d\n", results->whitespaceCount);
    fprintf(out_fp, "Number of unique words:,%d\n", results->uniqueCount);
    fprintf(out_fp, "Percentage of unique words to total words:,%.2f\n", results->uniqueRatio * 100);
    fprintf(out_fp, "Number of toxic words found:,%d\n", results->toxicWordFound);
    fprintf(out_fp, "Toxicity percentage of the sample text:,%.2f\n", results->toxicRatio * 100);
    fprintf(out_fp, "Average sentence length (words):,%.2f\n\n", (float)results-> totalWords / results->sentenceCount);

    // --- Write Unique Word Frequencies to output file ---
    fprintf(out_fp, "\n\nGeneral_Word_Frequencies\n");
    fprintf(out_fp, "Rank, Word, Frequency\n");
    for (int i = 0; i < results->uniqueCount; i++) {
        fprintf(out_fp, "No %d:,%20s,%d\n", i + 1, results->uniqueWords[i].word, results->uniqueWords[i].freq);
    }

    // --- Write Toxic Word Frequencies to output file ---
    fprintf(out_fp, "\n\nToxic_Word_Frequencies\n");
    fprintf(out_fp, "Rank,Toxic_Word,Frequency\n");
    for (int i = 0; i < results->uniqueToxicCount; i++) {
        fprintf(out_fp, "No %d:,%20s,%d\n", i + 1, results->uniqueToxicWords[i].toxicword, results->uniqueToxicWords[i].freqtoxic);
    }

    fclose(out_fp); // Close the output file
    printf("Analysis successfully saved to CSV file: %s\n\n", outputFilename); // Send confirmation message
}

// Function to add toxic words to the toxicwords.txt file
void add_words() {
    file = fopen("toxicwords.txt", "a"); // Open the toxicword dictionary file in append mode
    if (file == NULL) { // Check if file is present in the directory
        perror("Error opening file!\n\n");
    }

    printf("Enter a toxic word to add to the list: "); // Input prompt for user to add toxic word
    fgets(word_ADD, sizeof(word_ADD), stdin); // Collects the user's input
    word_ADD[strcspn(word_ADD, "\n")] = '\0'; // remove \n and replace it with null terminator
    fprintf(file, "\n%s", word_ADD); // add the new toxic word to the end of the file with a newline at the front
    fclose(file); // Close the file after writing
    free(file); // Free the memory allocated to the file pointer
    file = NULL; // Set the file pointer to NULL to avoid dangling pointer issues
    printf("Toxic word added successfully.\n\n"); // Print confirmation message
}

// Generate ASCII bar chart for top 10 toxic words
void bar_chart(AnalysisResults* results) {
    char array[10][40] = {0}; // Array to hold top 10 toxic words
    int frequency[10] = {0};  // initialize to zero

    // Populate arrays with top 10 toxic words and their frequencies
    for (size_t i = 0; i < 10 && i < results->uniqueToxicCount; i++) {
        strcpy(array[i], results->uniqueToxicWords[i].toxicword);
        frequency[i] = results->uniqueToxicWords[i].freqtoxic;
    }

    // Display the ASCII bar chart
    printf("\n-------------------------------------------------------------- ASCII Bar Chart ------------------------------------------------------\n");
    printf("'@' represents 500 frequency value, '!' represents 200 frequency value, '$' represents 100 frequency value, '&' represents 50 frequency value, '#' represents 10 frequency value, '|' represents 5 frequency value, '*' represents 1 frequency value\n\n");
    
    // Loop through top 10 toxic words
    for (size_t i = 0; i < 10 && i < results->uniqueToxicCount; i++) {
        printf("Top %d: %15s (frequency: %4d): ", i + 1, array[i], frequency[i]); // Print top 10 words and frequencies chronologically
        
        // Calculate the number of symbols to print for each frequency tier
        int five_hundreds = frequency[i] / 500;
        int two_hundreds = (frequency[i] - (five_hundreds * 500)) / 200;
        int hundreds = (frequency[i] - (five_hundreds * 500 + two_hundreds * 200)) / 100;
        int fifties = (frequency[i] % 100) / 50;
        int tens = (frequency[i] - (five_hundreds * 500 + two_hundreds * 200 + hundreds * 100 + fifties * 50)) / 10;
        int fives = ((frequency[i] % 50) - (tens * 10)) / 5;
        int units = (frequency[i] - (five_hundreds * 500 + two_hundreds * 200 + hundreds * 100 + fifties * 50 + tens * 10 + fives * 5));
        
        // For loops to print the corresponding number of symbols
        for (int g = 0; g < five_hundreds; g++) {
            printf("@");
        }
        for (int f = 0; f < two_hundreds; f++) {
            printf("!");
        }
        for (int e = 0; e < hundreds; e++) {
            printf("$");
        }
        for (int d = 0; d < fifties; d++) {
            printf("&");
        }
        for (int c = 0; c < tens; c++) {
            printf("#");
        }
        for (int b = 0 ; b < fives; b++) {
            printf("|");
        }
        for (int a = 0; a < units; a++) {
            printf("*");
        }
        printf("\n\n");
    }
}

// Display toxic stats by grabbing value from results struct after analysing
void ToxicDisplay(AnalysisResults* results) {
    printf("\n-----------------File Toxicity Stats-----------------\n");
    if (results->uniqueToxicCount <= 0) { // Check if no toxic words found
        printf("\nFile does not contain any toxic words.\n\n\n");
    }
    else {
        printf("Number of toxic words found: %d\n", results->toxicWordFound);
        printf("File Toxicity percentage: %.3f%%\n", results->toxicRatio * 100);
        printf("\nTop 10 most toxic Words\n");
        for (size_t i = 0; i < 10 && i < results->uniqueToxicCount; i++) {
            printf("%d) %s: %d\n", i + 1, results->uniqueToxicWords[i].toxicword, results->uniqueToxicWords[i].freqtoxic);
        }
        printf("\n\n"); 
    }
}

void compareToxicity() {
    ComparisonData data[2] = { 0 }; // Array to hold data for two files
    char temp_filename[MAX_WORD_LEN]; // Temporary buffer for filenames

    printf("\n--- Insert Analysis Reports ---\n");
    
    //Loop two times to let them enter two files to compare
    for (int i = 0; i < 2; i++) {
        printf("Enter Analysis CSV File %d name (e.g., fileA_analysis.csv): ", i + 1); // input analysis file
        
        //If fgets return NULL then show error using perror 
        if (fgets(temp_filename, sizeof(temp_filename), stdin) == NULL) {
            perror("Error reading input");
            return;
        }

        temp_filename[strcspn(temp_filename, "\n")] = '\0'; // Remove newline character
        strcpy(data[i].filename, temp_filename); // Copy to struct
        data[i].toxicRatio = 0.0f; // Initialize ratio

        FILE* fp = fopen(data[i].filename, "r");
        if (fp == NULL) { // Check if file exists
            printf("Error: Could not open file '%s'. Aborting comparison.\n\n", data[i].filename);
            return;
        }

        char line[300]; // Buffer to read each line from the CSV file
        int found = 0;

        // Loop through the CSV file to find the Toxic_Word_Frequencies line
        while (fgets(line, sizeof(line), fp)) {
            // Looking for the row: Toxic_Word_Frequencies,X.XX
            if (strstr(line, "Toxicity percentage of the sample text:") != NULL) {
                // Read the floating point value immediately following the comma
                char* comma = strchr(line, ',');
                if (comma) {
                    data[i].toxicRatio = atof(comma + 1);
                    found = 1;
                    break;
                }
            }
        }
        fclose(fp);

        if (!found) { // Check if the required line was found
            printf("Warning: Could not find 'Toxic_Word_Percentage' in '%s'. Aborting.\n\n", data[i].filename);
            return;
        }
    }

    // --- Display Comparison Results ---
    printf("\n--- Comparison Results ---\n");
    printf("File 1 (%s) Toxicity: %.2f%%\n", data[0].filename, data[0].toxicRatio);
    printf("File 2 (%s) Toxicity: %.2f%%\n", data[1].filename, data[1].toxicRatio);

    if (data[0].toxicRatio > data[1].toxicRatio) {
        printf("\nConclusion: File 1 is more toxic.\n\n");
    }
    else if (data[1].toxicRatio > data[0].toxicRatio) {
        printf("\nConclusion: File 2 is more toxic.\n\n");
    }
    else {
        printf("\nConclusion: Both files have equal toxicity.\n\n");
    }
}

int menu(AnalysisResults* results) {
    strcpy(results->filename, "None"); // Initialize filename to "None"
    int menuflag = 1; // Menu loop control flag

    while (menuflag == 1) {
        int analysis_ready = (results->totalWords > 0); // Check if option 2 has been run
        int file_loaded = (strcmp(results->filename, "None") != 0); // Check if a file was loaded in this session
        
        // Print out the menu display
        printf("TOXIC TEXT ANALYSER 1.0");
        printf("\n----------------------------------------\n");
        printf("1) Load sample file for analysis. (Current file loaded: %s)\n", results->filename);
        printf("2) Display general word statistics.\n");
        printf("3) Display toxic words analysis.\n");
        printf("4) Display top 10 toxic words & frequency bar chart.\n");
        printf("5) Save analysis results to record file.\n");
        printf("6) Add new toxic word into dictionary.\n");
        printf("7) Analysis files toxicity comparison.\n");
        printf("8) Exit the program.");
        printf("\n----------------------------------------\n");
        printf("Enter option:"); // Prompt for user input
        
        if (fgets(input_buffer, sizeof(input_buffer), stdin) == NULL) {
            perror("Error reading input.\n\n"); // Handle error if fgets fails
            return 1; // Or handle as appropriate
        }

        input_buffer[strcspn(input_buffer, "\n")] = 0;
        int is_valid = 1; // Assume valid until proven otherwise

        for (int i = 0; i < strlen(input_buffer); i++) {
            if (!isdigit((unsigned char)input_buffer[i])) {
                is_valid = 0; // Found a non-digit character
                printf("\nInvalid input. Please enter a number between 1 and 7.\n\n");
                break;
            }
        }

        if (is_valid) {
            int option = atoi(input_buffer); // Convert string to integer
            switch (option) {
            case 1:
                file_menu(results); 
                break;
            case 2:
                if (!file_loaded) { // Check if file is loaded
                    printf("\nError: Please load a file first (Option 1).\n\n");
                    break;
                }
                generalStats(results);
                break;
            case 3:
                if (!file_loaded) { // Check if file is loaded
                    printf("\nError: Please load a file first (Option 1).\n\n");
                    break;
                } else if (!analysis_ready) { // Check if analysis is done
                    printf("\nError: Please run analysis first (Option 2).\n\n");
                    break;
                }
                ToxicDisplay(results);
                break;
            case 4:
                if (!file_loaded) { // Check if file is loaded
                    printf("\nError: Please load a file first (Option 1).\n\n");
                    break;
                } else if (!analysis_ready) { // Check if analysis is done
                    printf("\nError: Please run analysis first (Option 2).\n\n");
                    break;
                }
                bar_chart(results);
                break;
            case 5:
                if (!file_loaded) { // Check if file is loaded
                    printf("\nError: Please load a file first (Option 1).\n\n");
                    break;
                } else if (!analysis_ready) { // Check if analysis is done
                    printf("\nError: Please run analysis first (Option 2).\n\n");
                    break;
                }
                Save_results_csv(results);
                break;
            case 6:
                add_words();
                break;
            case 7:
                compareToxicity();
                break;
            case 8:
                menuflag = 0; // Break the loop to exit
                printf("Exiting program...");
                break;
            }
        }
    }
    free(fptr); // Free the global file pointer
    fptr = NULL; // Clear the pointer
    getchar(); // Pause before exiting
    return 0;
}