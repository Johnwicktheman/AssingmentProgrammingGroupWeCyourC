#include "Toxiclib.h" // Include our self-defined header
char stopwords[MAX_STOPWORDS][MAX_WORD_LEN] = { 0 }; // Set the stopwords array to 0 to avoid garbage values
char toxicwords[MAX_TOXICWORDS][MAX_WORD_LEN] = { 0 }; // Set the toxicwords array to 0 to avoid garbage values
int stopwordCount = 0; // Initialize stopword count
int toxicwordCount = 0; // Initialize toxic word count

// Set of global variables declared for easier intialization throughout the program
FILE* fptr, * file;
char content[MAX_WORDS] = { 0 }; // Used in file_menu()
char word_ADD[BUFFER_SIZE] = { 0 }; // Used in add_words()
char file_name[BUFFER_SIZE] = { 0 }; // Used in file_menu()
char filenamearray[MAX_WORD_LEN] = { 0 }; // Used in file_menu()
char input_buffer[100] = { 0 }; // Used in menu()

int main() {
    remove("read.txt"); // Delete read.txt each time the program starts to ensure fresh analysis
    AnalysisResults results = { 0 }; // Initialize all fields in the struct to zero
    results.uniqueCapacity = 100; // Set initial unique word capacity
    results.uniqueToxicCapacity = 10; // Set initial unique toxic word capacity

    // Initialize dynamic memory allocation
    results.uniqueWords = malloc(results.uniqueCapacity * sizeof(WordEntry));
    if (!results.uniqueWords) {
        perror("Initial uniqueWords allocation failed");
        return 1;
    }
    results.uniqueToxicWords = malloc(results.uniqueToxicCapacity * sizeof(ToxicWordEntry));
    if (!results.uniqueToxicWords) {
        perror("Initial uniqueToxicWords allocation failed");
        free(results.uniqueWords);
        return 1;
    }

    // Call the menu function to start the program
    menu(&results);

    // Free dynamically allocated memory before exiting
    free(results.uniqueWords);
    free(results.uniqueToxicWords);

    return 0;
}